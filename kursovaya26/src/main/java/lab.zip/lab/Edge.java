package lab;

public class Edge {
    public int target;
    public int weight;
    public int condition;
    public Edge (int t) {
        target = t;
    }
    public Edge (int t, int w) {
        target = t;
        weight = w;
    }
    public Edge (int t, int w, int c) {
        target = t;
        weight = w;
        condition = c;
    }
    public Edge (int t, int c, String empty) {
        target = t;
        condition = c;
    }
}
