package lab;

import lab.Graph;
public class Main {
    public static void main(String[] args) {
        Graph G = new Graph();

    }
}