package lab;


import java.util.*;

import static java.lang.Math.random;
import static lab.probability.prob;

public class Graph {    //в этом классе dag функция (возвращает switching мб (мб switching ребра между ксс?))
    private Map<Integer, List<Edge>> edgeList = new HashMap<>();
    //private final Set<Integer> dfsVisited = new HashSet<>();

    public void addEdge (int u, int v) {
        edgeList.computeIfAbsent(u, k -> new ArrayList<>()).add(new Edge(v));
    }

    public void addEdge (int u, int v, int w) {
        edgeList.computeIfAbsent(u, k -> new ArrayList<>()).add(new Edge(v, w));
    }

    public boolean has (int u) {
        for (int vertice : edgeList.keySet()) {
            if (vertice == u) {
                return true;
            }
            for (Edge out : edgeList.getOrDefault(vertice, Collections.emptyList())) {
                if (out.target == u) {
                    return true;
                }
            }
        }
        return false;
    }

    public void clearGraph () {
        edgeList = new HashMap<>();
    }

    public void generate (int size, char type, int maxWeight) {
        double koeff;
        int random;
        clearGraph();
        if (type == 'r') {
            koeff = 1.0 / size;
        }
        else {
            koeff = 1.0 / 2.0;
        }
        for (int u = 0; u < size; u++) {
            for (int v = 0; v < size; v++) {
                if (prob(koeff) && v != u) {
                    if (maxWeight < 1) {
                        addEdge(u, v);
                    }
                    else {
                        addEdge(u, v, (int)(1.0/maxWeight+random()*(maxWeight - 1)/maxWeight));
                    }
                }
            }
        }
        for (int u = 0; u < size; u++) {
            if (!has(u)) {
                do {
                    random = (int) (random() * (size - 1));
                }
                while (random == u);
                if (prob(0.5)) {
                    addEdge (u, random);
                }
                else{
                    addEdge(random, u);
                }
            }
        }
    }

    public SwitchingGraph DAGCompression () {
        return new SwitchingGraph();
    }

    /*public void dfs (int node) {
        dfsVisited.add(node);
        // <- Здесь манипуляции с вершиной
        for (int neighbor : edgeList.getOrDefault(node, Collections.emptyList())) {
            if (!dfsVisited.contains(neighbor)) {
                dfs(neighbor);
            }
        }
    }*/
}
