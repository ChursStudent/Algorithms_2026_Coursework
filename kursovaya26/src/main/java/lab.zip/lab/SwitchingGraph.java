package lab;

import org.w3c.dom.Node;

import javax.swing.plaf.nimbus.NimbusLookAndFeel;
import java.util.*;

public class SwitchingGraph {   //в этом классе dfs/bfs/dajekstra
    private Map<Integer, List<Edge>> edgeList = new HashMap<>();

    public void addEdge (int u, int v, int w) {
        edgeList.computeIfAbsent(u, k -> new ArrayList<>()).add(new Edge(v, w));
    }

    public void addSwitchingEdge (int u, int v, int w, int c) {
        edgeList.computeIfAbsent(u, k -> new ArrayList<>()).add(new Edge(v, w, c));
    }

    public void switchEdges (int u) {
        for (Edge out : edgeList.getOrDefault(u, Collections.emptyList())) {
            if (out.condition == 0) {
                out.condition = 1;
            }
            else if (out.condition == 1) {
                out.condition = 0;
            }
        }
    }

    public void DFS (int start) {
        System.out.println("DFS");
        Set<Integer> visited = new HashSet<>();
        dfsRecursion (start, visited);
    }

    public void dfsRecursion (int current, Set<Integer> visited) {
        visited.add(current);
        System.out.print(current + " ");
        for (Edge out : edgeList.getOrDefault(current, Collections.emptyList())) {
            if (!visited.contains(out.target) && out.condition != 0) {
                dfsRecursion(out.target, visited);
            }
        }
    }

    public void BFS (int start) {
        System.out.println("BFS");
        Set<Integer> visited = new HashSet<>();
        Queue<Integer> queue = new LinkedList<>();
        int current;
        visited.add(start);
        queue.add(start);
        while (!queue.isEmpty()) {
            current = queue.poll();
            System.out.print(current + " ");
            for (Edge out : edgeList.getOrDefault(current, Collections.emptyList())) {
                if (!visited.contains(out.target) && out.condition != 0) {
                    visited.add(out.target);
                    queue.add(out.target);
                }
            }
        }
    }

    public static class NodeDistance implements Comparable<NodeDistance> {
        int node;
        int distance;

        public NodeDistance (int n, int d) {
            node = n;
            distance = d;
        }

        @Override
        public int compareTo (NodeDistance other) {
            return Integer.compare(distance, other.distance);
        }
    }
    public int[] dijkstra (int source, int size) {
        int[] distances = new int[size];
        NodeDistance current;
        int u;
        int v;
        int w;
        Arrays.fill(distances, Integer.MAX_VALUE);
        distances[source] = 0;

        PriorityQueue<NodeDistance> pQ = new PriorityQueue<>();
        pQ.add(new NodeDistance(source, 0));

        while (!pQ.isEmpty()) {
            current = pQ.poll();
            u = current.node;

            if (current.distance > distances[u]) {
                continue;
            }

            for (Edge e : edgeList.get(u)) {
                v = e.target;
                w = e.weight;

                if (distances[u] != Integer.MAX_VALUE && distances[u] + w < distances[v]) {
                    distances[v] = distances[u] + w;
                    pQ.add(new NodeDistance(v, distances[v]));
                }
            }
        }
        return distances;
    }

}
