package lab;

public class visualize {    //функции для отрисовки обычного и switching
}
